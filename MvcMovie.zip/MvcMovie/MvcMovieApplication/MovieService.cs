﻿namespace MvcMovieApplication
{
    public class MovieService
    {

    }
}